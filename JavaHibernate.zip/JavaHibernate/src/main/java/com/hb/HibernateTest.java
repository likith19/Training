package com.hb;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.hb.dto.UserAddress;
import com.hb.dto.UserDetails;
import com.hb.utils.HibernateUtils;

public class HibernateTest {
	private static final SessionFactory factory = HibernateUtils.factory;

	public static void main(String[] args) {
		
		UserDetails user = new UserDetails();
		user.setName("Soni");
		UserAddress address = new UserAddress();
		address.setCity("Melbourne");
		address.setPinCode("12345");
		user.setAddress(address);
				
		Session session = factory.openSession();
		Transaction tx= session.beginTransaction();
		session.save(user);
		tx.commit();	
		session.close();
		
		/*session = factory.openSession();
		session.beginTransaction();
		user = (UserDetails) session.get(UserDetails.class, 2);
		System.out.println("User Name: " + user.getName());*/
		
		
	}

}
