package com.prc.test;

import net.webservicex.GlobalWeather;
import net.webservicex.GlobalWeatherSoap;

public class GlobalWeatherClient {

	public static void main(String[] args) {
		
		String countryName = args[0];
		
		GlobalWeather gw = new GlobalWeather();
		GlobalWeatherSoap gws = gw.getGlobalWeatherSoap();
		String name=gws.getCitiesByCountry(countryName);
		System.out.println(name);
	}

}
